import React from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import '../../SCSS/popups.scss';

const JobUpdateForm = ({ jobCodes, serviceTypes, paymentTerms }) => {



    return (
    
        <div className='d-flex flex-wrap w-100'>
           
            <div className='w-50 py-2 pe-4'>
            <FloatingLabel label="Client">
                    <Form.Select aria-label="Client" name='customer'>
                        <option>Select Client</option>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>
                        <option value="3">Contract Phase</option>
                    </Form.Select>
                </FloatingLabel>
                </div>
            <div className='w-50 py-2'>
            <FloatingLabel label="Job Code">
                    <Form.Select aria-label="Job Code" name='type'>
                        <option key={0}>Assign Code</option>
                        {jobCodes?.length > 0 && jobCodes.map((item) => {
                            return <option key={item.id} value={item.id}>{item.name}</option>
                        })}
                    </Form.Select>
                </FloatingLabel>
                </div>
        
            <div className='w-50 py-2 pe-4'>
            <FloatingLabel label="Job Name">
                    <Form.Control type="text" placeholder="Job Name" name='name' />
                </FloatingLabel>
                </div>
            <div className='w-50 py-2 '>
            <FloatingLabel label="Job Description (will appear on customer invoice)">
                    <Form.Control
                        as="textarea"
                        placeholder="Leave a comment here"
                        style={{ height: '100px' }}
                        name='description'
                    />
                </FloatingLabel>
                </div>
            <div className='w-50 py-2 pe-4'>
            <FloatingLabel label="Responsible User">
                    <Form.Select aria-label="Responsible User" name=''>
                        <option>Assign Code</option>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>
                        <option value="3">Contract Phase</option>
                    </Form.Select>
                </FloatingLabel>
                </div>
            <div className='w-50 py-2'>
            <FloatingLabel label="Project Deadline">
                    <Form.Control type="date" placeholder="Project Deadline" name='deadline' />
                </FloatingLabel>
                </div>
            <div className='w-50 py-2 pe-4'>
            <FloatingLabel label="Desired Due Date">
                    <Form.Control type="date" placeholder="Desired Due Date" name='desired_due_date' />
                </FloatingLabel>
                </div>
            <div className='w-50 py-2'>
            <Form.Check // prettier-ignore
                type="checkbox"
                label="Urgent / Priority"
                name='priority'
                value='on'
              />
                </div>
            <div className='w-50 py-2 pe-4'>
            <FloatingLabel label="Status">
                    <Form.Select aria-label="Responsible User" name='status'>
                        <option>In Progress</option>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>
                        <option value="3">Contract Phase</option>
                    </Form.Select>
                </FloatingLabel>
                </div>
            <div className='w-50 py-2'>
            <Form.Check // prettier-ignore
                type="checkbox"
                label="Mark as completed"
              />
          
                </div>
            <div className='w-50 py-2 pe-4'>
            <Form.Check // prettier-ignore
                type="checkbox"
                label="Recurring Job"
              />
         
                </div>
            <div className='w-100 py-2 '>
            <FloatingLabel label="Job Description (will appear on customer invoice)">
                    <Form.Control
                        as="textarea"
                        placeholder="Leave a comment here"
                        style={{ height: '100px' }}
                        
                    />
                </FloatingLabel>
                </div>
                {/* =========== */}
                <div className='w-50 py-2'>
            <FloatingLabel label="Project Deadline">
                    <Form.Control type="date" placeholder="Project Deadline" name='deadline' />
                </FloatingLabel>
                </div>
                <div className='w-50 py-2 pe-4'>
                <FloatingLabel label="TASK / HOURLY BILLING & COMPLETE JOB / FLAT RATE BILLING *">
                    <Form.Select aria-label="Responsible User" name='projected_hours'>
                        <option>Select billing type</option>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>
                        <option value="3">Contract Phase</option>
                    </Form.Select>
                </FloatingLabel>
                </div>
                <div className='w-50 py-2'>
                <FloatingLabel label="PAYMENT TERM">
                    <Form.Select aria-label="Responsible User" name='billing_type'>
                        <option key={0}>Select Payment type</option>
                        {paymentTerms?.length > 0 && paymentTerms.map((item) => {
                            return <option key={item.id} value={item.id}>{item.name}</option>
                        })}
                    </Form.Select>
                </FloatingLabel>
                </div>
                <div className='w-50 py-2'>
                <h4>PLEASE SAVE JOB TO ASSIGN MULTIPLE USERS.</h4>
                </div>
        </div>
    
      );
    }

export default JobUpdateForm;
