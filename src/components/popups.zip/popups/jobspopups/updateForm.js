import React, { useEffect, useState } from 'react';
import '../../SCSS/popups.scss';
import * as MdIcons from 'react-icons/md';
import Button from '../../commonModules/UI/Button';
import { updateJob } from '../../../API/authCurd';
import ErrorPopup from '../../commonModules/UI/ErrorPopup';
import UpadateJobForm from './updateJobForm';

const UpdateForm = (props) => {
    const [popMsg, setPopMsg] = useState(false);
    const [isError, setIsError] = useState(false)
    const [errMessage, setErrMessage] = useState();
    const [isUpdating, setIsUpdating] = useState(false)
    const [updatedJobData, setUpdateJobdData] = useState(null)

    useEffect(() => {
        if (props?.selectedJob) {
            const { customer, status, type, name, description, deadline, desired_due_date, priority, recurrence_frequency, start_date, end_date, billing_type, projected_hours, created_at, updated_at, customer_details } = props?.selectedJob
            let data = {
                name: name ?? (name === "" ? "" : name),
                type: type ?? (type === "" ? "" : type),
                status: status ?? (status === "" ? "" : status),
                customer: customer ?? (customer === "" ? "" : customer),
                description: description ?? (description === "" ? "" : description),
                deadline: deadline ?? (deadline === "" ? "" : deadline),
                desired_due_date: desired_due_date ?? (desired_due_date === "" ? "" : desired_due_date),
                priority: priority ?? (priority === "" ? "" : priority),
                recurrence_frequency: recurrence_frequency ?? (recurrence_frequency === "" ? "" : recurrence_frequency),
                start_date: start_date ?? (start_date === "" ? "" : start_date),
                end_date: end_date ?? (end_date === "" ? "" : end_date),
                billing_type: billing_type ?? (billing_type === "" ? "" : billing_type),
                projected_hours: projected_hours ?? (projected_hours === "" ? "" : projected_hours),
                created_at: created_at ?? (created_at === "" ? "" : created_at),
                updated_at: updated_at ?? (updated_at === "" ? "" : updated_at),
                customer_details: customer_details ?? (customer_details === "" ? "" : customer_details)
            }
            setUpdateJobdData(data)
        }
    }, [props?.selectedJob])

    function handleSubmit(event) {
        event.preventDefault();
        setIsUpdating(true)
        updateJob(updatedJobData, props.selectedJob.id)
            .then((res) => {
                let SuccessfullyMessage = res.data.message;
                props.getJobList()
                setIsUpdating(false)
                setIsError(false)
                setErrMessage(SuccessfullyMessage)
                setPopMsg(true)
            })
            .catch((err) => {
                console.log("123456",err)
                let errorMessage = err.response
                setIsUpdating(false)
                setIsError(true)
                setErrMessage(errorMessage)
                setPopMsg(true)
            })
    }


    function errorPopupOnClick() {
        setPopMsg(false)
        if (!isError) {
            props.onClick()
        }
    }

    if (popMsg) {
        return (
            <ErrorPopup title={errMessage} onClick={errorPopupOnClick} />
        )
    }

    return (
        <form onSubmit={handleSubmit}>
            <div className='popups d-flex justify-content-center align-items-center'>
                <div className='addpopups'>
                    <div className='mb-auto pophead d-flex align-items-center justify-content-between'>
                        <div>Update Client</div>
                        <div className='myIcon' type="button" onClick={props.onClick}><MdIcons.MdOutlineClose /></div>
                    </div>
                    <div className='popBody p-3'>
                        <UpadateJobForm
                            jobCodes={props.jobCodes}
                            paymentTerms={props.paymentTerms}
                            customerList={props.customerList}
                            updatedJobData={updatedJobData}
                            setUpdateJobdData={setUpdateJobdData}
                        />
                    </div>
                    <div className='mt-auto popfoot w-100 p-2'>
                        <div className='d-flex align-items-center justify-content-center'>
                            <Button className="mx-4 cclBtn" onClick={props.onClick}>Cancel</Button>
                            <Button type="submit" disable={isUpdating}>Update</Button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
}

export default UpdateForm;
