import React from 'react';
import '../../SCSS/popups.scss';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import InputField from '../../commonModules/UI/InputField';
import SelectField from '../../commonModules/UI/SelectField';
import SqButton from '../../commonModules/UI/SqButton';
import TableBtn from "../../commonModules/UI/TableBtn";
import * as RiIconIcons from "react-icons/ri";
import * as FiIcons from "react-icons/fi";

const Taskspopcol1 = () => {

    const CustomerTable = [
        {
          name: "Ryan Speer",
          email: "Aug 2, 2002",
          address: "TX.",
          status: "Completed",
    
        },
        {
          name: "Ryan Speer",
          email: "Aug 2, 2002",
          address: "TX.",
          status: "process",
        },
        {
          name: "Ryan Speer",
          email: "Aug 2, 2002",
          address: "TX.",
          status: "Urgent",
        },
      ];

  return (
    <div className='px-3 py-1 popcol1'>
      <div className='py-2'>
            <FloatingLabel label="Status">
                <Form.Select aria-label="Floating label select example" name='status'>
                <option value="Male">Client*</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
                </Form.Select>
            </FloatingLabel>
        </div>
      <div className='py-2'>
            <FloatingLabel label="Status">
                <Form.Select aria-label="Floating label select example" name='status'>
                <option value="Male">Jobs*</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
                </Form.Select>
            </FloatingLabel>
        </div>
      <div className='py-2'>
            <FloatingLabel label="Status">
                <Form.Select aria-label="Floating label select example" name='status'>
                <option value="Male">Jobs*</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
                </Form.Select>
            </FloatingLabel>
        </div>
      <div className='py-2'>
      <FloatingLabel label="Task Name">
                <Form.Control type="text" placeholder="Website" name='website' />
            </FloatingLabel>
        </div>
      <div className='py-2'>
      <FloatingLabel label="Task Details">
                <Form.Control
                    as="textarea"
                    placeholder="Task Details"
                    style={{ height: '50px' }}
                    name='management_comment'
                />
            </FloatingLabel>
        </div>
      <div className='py-2'>
      <Form.Check 
            type="checkbox"
            label="Customer Review Task"
            name='priority'
            value='on'
          />
        </div>
      <div className='py-2'>
      <Form.Check 
            type="checkbox"
            label="Task Being Worked On"
            name='priority'
            value='on'
          />
        </div>
        <div className='py-2'>
            <FloatingLabel label="Status">
                <Form.Select aria-label="Floating label select example" name='status'>
                <option value="Male">Service Type*</option>
              <option value="Male">India</option>
              <option value="Male">United Kingdom</option>
                </Form.Select>
            </FloatingLabel>
        </div>
        <div className='py-2'>
        <FloatingLabel label="Desired Due Date">
                <Form.Control type="date" placeholder="Desired Due Date" name='desired_due_date' />
            </FloatingLabel>
        </div>
        <div className='py-2'>
        <Form.Check
            type="checkbox"
            label="Urgent / Priority"
            name='priority'
            value='on'
          />
        </div>
          
          <div className='px-2 py-1 d-flex align-items-center justify-content-between popSubTitle'>
            ASSIGNED USER(S) <SqButton className="popSubBtn"> + Assigned Urs</SqButton>
          </div>
          <div className="custTable">
            <table>
              <tr>
                <th>Name</th>
                <th>Due Date</th>
                <th>STS</th>
                <th></th>
              </tr>
              {CustomerTable.map((cust, index) => (
                <tr>
                  <td>{cust.name}</td>
                  <td>{cust.email}</td>
                  <td>
                    <div className="clrStatus" style={{
                      backgroundColor:
                        ((cust.status === 'Completed' && '#2705FA') ||
                          (cust.status === 'Updated' && '#a563a6') ||
                          (cust.status === 'Urgent' && '#Ff6161')
                        )
                    }}></div>
                  </td>
                  <td>
                    <div className="grpofBtn">
                      <TableBtn className="edit">
                        <FiIcons.FiEdit />
                      </TableBtn>
                      <TableBtn className="delete">
                        <RiIconIcons.RiDeleteBin6Line />
                      </TableBtn>

                    </div>
                  </td>
                </tr>
              ))}
            </table>
          </div>
        </div>
  );
}

export default Taskspopcol1;
