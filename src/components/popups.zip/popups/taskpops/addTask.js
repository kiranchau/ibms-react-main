import React, { useState } from 'react';
import '../../SCSS/popups.scss';
import * as MdIcons from 'react-icons/md';
import Button from '../../commonModules/UI/Button';
import TaskForm from './taskForm';
import ErrorPopup from '../../commonModules/UI/ErrorPopup';
import axios from 'axios';

const AddTask = (props) => {
    const [popMsg, setPopMsg] = useState(false);
    const [errMessage, setErrMessage] = useState();

    function handleSubmit(event) {
        event.preventDefault();
        const fd = new FormData(event.target);
        const data = Object.fromEntries(fd.entries())
        console.log(data);
        axios.post("https://57a8-103-164-240-25.ngrok-free.app/api/task", data, {
            headers: {
                "Content-Type": "application/json",
                'Authorization': 'Bearer ' + localStorage.getItem('token'),
                'ngrok-skip-browser-warning': 'true'
            }
        })
            .then((res) => {
                console.log(res.data.message)
                //    alert("Customer Successfully added")
                let SuccessfullyMessage = res.data.message;
                setErrMessage(SuccessfullyMessage)
                props.getTaskList();
                setPopMsg(true)
            })
            .catch((err) => {
                console.log(err)
                let errorMessage = err.response.data.message;
                setErrMessage(errorMessage)
                setPopMsg(true)
            })
    }

    // if(popMsg){
    //     return(
    //       <ErrorPopup title={errMessage}  onClick={() => setPopMsg(false)}/>
    //     )
    //   }

    return (
        <form onSubmit={handleSubmit}>
            <div className='popups d-flex justify-content-center align-items-center'>
                <div className='addpopups'>
                    <div className='mb-auto pophead d-flex align-items-center justify-content-between'>
                        <div>Add Task</div>
                        <div className='myIcon' onClick={props.onClick} type="button"><MdIcons.MdOutlineClose /></div>
                    </div>
                    <div className='popBody p-3'>
                        <TaskForm
                            jobCodes={props.jobCodes}
                            serviceTypes={props.serviceTypes}
                            paymentTerms={props.paymentTerms}
                            customerList={props.customerList}
                        />
                    </div>
                    <div className='mt-auto popfoot w-100 p-2'>
                        <div className='d-flex align-items-center justify-content-center'>
                            <Button className="mx-4 cclBtn" onClick={props.onClick}>Cancel</Button>
                            <Button type="submit">Save</Button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
}

export default AddTask;
