import react , {useState} from 'react'
import * as MdIcons from 'react-icons/md';
import Button from '../../commonModules/UI/Button';
import { addCust } from '../../../API/authCurd';
import ErrorPopup from '../../commonModules/UI/ErrorPopup';
import TaskUpdateForm from './TaskUpdateForm';


const UpdateTask = (props) => {
 
  
    const [popMsg, setPopMsg] = useState(false);
    const [errMessage, setErrMessage] = useState();


    function handleSubmit(event){
        event.preventDefault();
    
        const fd = new FormData(event.target);
        const data = Object.fromEntries(fd.entries())
       
        addCust(data)
        .then((res) =>{
            console.log(res.data.message)
        //    alert("Customer Successfully added")
           let SuccessfullyMessage = res.data.message;
           setErrMessage(SuccessfullyMessage)
            setPopMsg(true)
        })
        .catch((err) =>{
            console.log(err)
            let errorMessage = err.response.data.message;
            setErrMessage(errorMessage)
            setPopMsg(true)
        } )
    }

    if(popMsg){
        return(
          <ErrorPopup title={errMessage}  onClick={() => setPopMsg(false)}/>
        )
      }

    return (
        <form onSubmit={handleSubmit}>
        <div className='popups d-flex justify-content-center align-items-center'>
        <div className='addpopups'>
            <div className='mb-auto pophead d-flex align-items-center justify-content-between'>
                <div>Add Client</div>
                <div className='myIcon'type="button" onClick={props.onClick}><MdIcons.MdOutlineClose /></div>
            </div>
            <div className='popBody p-3'>                
                    <TaskUpdateForm />                
            </div>
            <div className='mt-auto popfoot w-100 p-2'>
                <div className='d-flex align-items-center justify-content-center'>
                    <Button className="mx-4 cclBtn">Cancel</Button>
                    <Button type="submit">Update</Button>
                </div>
            </div>
            </div>
           

        </div>
        </form>
    );
}

export default UpdateTask;
