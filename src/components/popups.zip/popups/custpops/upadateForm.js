import React from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import '../../SCSS/popups.scss';

const UpadateForm = ({ updatedData, setUpdatedData, paymentTerms, clientStatus }) => {
    const onChangeHandler = (e) => {
        setUpdatedData({ ...updatedData, [e.target.name]: e.target.value })
    }

    return (
        <div className='d-flex flex-wrap w-100'>
            <div className='w-100 addCust'>
                <div className='w-50'>
                    <FloatingLabel label="Name">
                        <Form.Control
                            type="text" name='name'
                            value={updatedData?.name ?? ""}
                            onChange={onChangeHandler}
                        />
                    </FloatingLabel>
                </div>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="Status">
                    <Form.Select
                        aria-label="Floating label select example" name='status'
                        value={updatedData?.status ?? ""}
                        onChange={onChangeHandler}
                    >
                        <option key={0}>Select Status</option>
                        {clientStatus?.length > 0 && clientStatus.map((item) => {
                            return <option key={item.id} value={item.id}>{item.name}</option>
                        })}
                    </Form.Select>
                </FloatingLabel>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="Email">
                    <Form.Control
                        type="text" name='email'
                        value={updatedData?.email ?? ""}
                        onChange={onChangeHandler}
                    />
                </FloatingLabel>
            </div>
            <div className='addCust'>
                <FloatingLabel label="Website">
                    <Form.Control
                        type="text" name='website'
                        value={updatedData?.website ?? ""}
                        onChange={onChangeHandler}
                    />
                </FloatingLabel>
            </div>
            <div className='d-flex addCust pe-5'>
                <div className='w-75 pe-3'>
                    <FloatingLabel label="Phone Number">
                        <Form.Control
                            type="tel" name='phone'
                            value={updatedData?.phone ?? ""}
                            onChange={onChangeHandler}
                        />
                    </FloatingLabel>
                </div>
                <div>
                    <FloatingLabel label="No. of">
                        <Form.Select
                            aria-label="Floating label select example" name='type'
                            value={updatedData?.type ?? ""}
                            onChange={onChangeHandler}
                        >
                            <option>Number of</option>
                            <option value="1">Mobile</option>
                            <option value="2">Office</option>
                            <option value="3">Home</option>
                            <option value="4">Fax</option>
                        </Form.Select>
                    </FloatingLabel>
                </div>
            </div>

            <div className='addCust pe-5'>
                <FloatingLabel label="Addresss">
                    <Form.Control
                        type="text" name='address1'
                        value={updatedData?.address1 ?? ""}
                        onChange={onChangeHandler}
                    />
                </FloatingLabel>
            </div>
            <div className='addCust'>
                <FloatingLabel label="Address line 2">
                    <Form.Control
                        type="text" name='address2'
                        value={updatedData?.address2 ?? ""}
                        onChange={onChangeHandler}
                    />
                </FloatingLabel>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="City">
                    <Form.Select
                        name='city'
                        value={updatedData?.city ?? ""}
                        onChange={onChangeHandler}
                    >
                        <option>select city</option>
                        <option value="1">Pune</option>
                        <option value="2">Satara</option>
                        <option value="3">Sambhaji Nagar</option>
                        <option value="4">Ahmednagar</option>
                    </Form.Select>
                </FloatingLabel>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="State">
                    <Form.Select
                        name='state'
                        value={updatedData?.state ?? ""}
                        onChange={onChangeHandler}
                    >
                        <option>Select State</option>
                        <option value="1">Maharashtra</option>
                        <option value="2">Delhi</option>
                        <option value="3">Tamil Nadu</option>
                        <option value="4">Kashmir</option>
                    </Form.Select>
                </FloatingLabel>
            </div>

            <div className='addCust'>
                <FloatingLabel label="Default Payment Terms">
                    <Form.Select
                        name='crm'
                        value={updatedData?.crm ?? "0"}
                        onChange={onChangeHandler}
                    >
                        <option key={0} value="0">Select Payment type</option>
                        {paymentTerms?.length > 0 && paymentTerms.map((item) => {
                            return <option key={item.id} value={item.id}>{item.name}</option>
                        })}
                    </Form.Select>
                </FloatingLabel>
            </div>
            <div className='w-50 pe-5'>
                <FloatingLabel label="Management Comments">
                    <Form.Control
                        as="textarea"

                        style={{ height: '100px' }}
                        name='management_comment'
                        value={updatedData?.management_comment ?? ""}
                        onChange={onChangeHandler}
                    />
                </FloatingLabel>
            </div>
            <div className='w-50 addCust'>
                <FloatingLabel label="Contract Terms">
                    <Form.Control
                        as="textarea"

                        style={{ height: '100px' }}
                        name='contract_term'
                        value={updatedData?.contract_term ?? ""}
                        onChange={onChangeHandler}
                    />
                </FloatingLabel>
            </div>
        </div>
    );
}

export default UpadateForm;
