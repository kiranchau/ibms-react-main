import React from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import '../../SCSS/popups.scss';

const CustForm = (props) => {
    return (
        <div className='d-flex flex-wrap w-100'>
            <div className='w-100 addCust'>
                <div className='w-50'>
                    <FloatingLabel label="Name">
                        <Form.Control type="text" placeholder="Name" name='name' />
                    </FloatingLabel>
                </div>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="Status">
                    <Form.Select aria-label="Floating label select example" name='status'>
                        <option key={0}>Select Status</option>
                        {props?.clientStatus?.length > 0 && props?.clientStatus.map((item) => {
                            return <option key={item.id} value={item.id}>{item.name}</option>
                        })}
                    </Form.Select>
                </FloatingLabel>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="Email">
                    <Form.Control type="text" placeholder="Email" name='email' />
                </FloatingLabel>
            </div>
            <div className='addCust'>
                <FloatingLabel label="Website">
                    <Form.Control type="text" placeholder="Website" name='website' />
                </FloatingLabel>
            </div>
            <div className='d-flex addCust pe-5'>
                <div className='w-75 pe-3'>
                    <FloatingLabel label="Phone Number">
                        <Form.Control type="tel" placeholder="Phone Number" name='phone' />
                    </FloatingLabel>
                </div>
                <div>
                    <FloatingLabel label="No. of">
                        <Form.Select aria-label="Floating label select example" name='type'>
                            <option>Number of</option>
                            <option value="1">Mobile</option>
                            <option value="2">Office</option>
                            <option value="3">Home</option>
                            <option value="4">Fax</option>
                        </Form.Select>
                    </FloatingLabel>
                </div>
            </div>

            <div className='addCust pe-5'>
                <FloatingLabel label="Addresss">
                    <Form.Control type="text" placeholder="Address" name='address1' />
                </FloatingLabel>
            </div>
            <div className='addCust'>
                <FloatingLabel label="Address line 2">
                    <Form.Control type="text" placeholder="Address Line 2" name='address2' />
                </FloatingLabel>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="City">
                    <Form.Select name='city'>
                        <option>select city</option>
                        <option value="1">Pune</option>
                        <option value="2">Satara</option>
                        <option value="3">Sambhaji Nagar</option>
                        <option value="4">Ahmednagar</option>
                    </Form.Select>
                </FloatingLabel>
            </div>
            <div className='addCust pe-5'>
                <FloatingLabel label="State">
                    <Form.Select name='state'>
                        <option>Select State</option>
                        <option value="1">Maharashtra</option>
                        <option value="2">Delhi</option>
                        <option value="3">Tamil Nadu</option>
                        <option value="4">Kashmir</option>
                    </Form.Select>
                </FloatingLabel>
            </div>

            <div className='addCust'>
                <FloatingLabel label="Default Payment Terms">
                    <Form.Select name='crm'>
                        <option key={0} value="0">Select Payment type</option>
                        {props?.paymentTerms?.length > 0 && props?.paymentTerms.map((item) => {
                            return <option key={item.id} value={item.id}>{item.name}</option>
                        })}
                    </Form.Select>
                </FloatingLabel>
            </div>
            <div className='w-50 pe-5'>
                <FloatingLabel label="Management Comments">
                    <Form.Control
                        as="textarea"
                        placeholder="Leave a comment here"
                        style={{ height: '100px' }}
                        name='management_comment'
                    />
                </FloatingLabel>
            </div>
            <div className='w-50 addCust'>
                <FloatingLabel label="Contract Terms">
                    <Form.Control
                        as="textarea"
                        placeholder="Leave a comment here"
                        style={{ height: '100px' }}
                        name='contract_term'
                    />
                </FloatingLabel>
            </div>
        </div>
    );
}

export default CustForm;
