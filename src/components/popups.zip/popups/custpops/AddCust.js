import React, { useState } from 'react';
import '../../SCSS/popups.scss';
import * as MdIcons from 'react-icons/md';
import Button from '../../commonModules/UI/Button';
import CustForm from './custForm';
import ErrorPopup from '../../commonModules/UI/ErrorPopup';
import { addCust } from '../../../API/authCurd';

const AddCust = (props) => {
    const [popMsg, setPopMsg] = useState(false);
    const [errMessage, setErrMessage] = useState();
    const [isError, setIsError] = useState(false)

    function handleSubmit(event) {
        event.preventDefault();

        const fd = new FormData(event.target);
        const data = Object.fromEntries(fd.entries())

        addCust(data)
            .then((res) => {
                console.log(res.data.message)
                let SuccessfullyMessage = res.data.message;
                props.getCustomersList()
                setIsError(false)
                setErrMessage(SuccessfullyMessage)
                setPopMsg(true)
            })
            .catch((err) => {
                console.log(err)
                let errorMessage = err.response?.data.message || "Something went wrong!"
                setIsError(true)
                setErrMessage(errorMessage)
                setPopMsg(true)
            })
    }

    function errorPopupOnClick() {
        setPopMsg(false)
        if (!isError) {
            props.onClick()
        }
    }

    if (popMsg) {
        return (
            <ErrorPopup title={errMessage} onClick={errorPopupOnClick} />
        )
    }

    return (
        <form onSubmit={handleSubmit}>
            <div className='popups d-flex justify-content-center align-items-center'>
                <div className='addpopups'>
                    <div className='mb-auto pophead d-flex align-items-center justify-content-between'>
                        <div>Add Client</div>
                        <div className='myIcon' type="button" onClick={props.onClick}><MdIcons.MdOutlineClose /></div>
                    </div>
                    <div className='popBody p-3'>
                        <CustForm paymentTerms={props.paymentTerms} clientStatus={props.clientStatus} />
                    </div>
                    <div className='mt-auto popfoot w-100 p-2'>
                        <div className='d-flex align-items-center justify-content-center'>
                            <Button className="mx-4 cclBtn" onClick={props.onClick}>Cancel</Button>
                            <Button type="submit">Save</Button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
}

export default AddCust;
