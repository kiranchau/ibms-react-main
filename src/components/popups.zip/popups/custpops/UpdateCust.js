import React, { useEffect, useState } from 'react';
import '../../SCSS/popups.scss';
import * as MdIcons from 'react-icons/md';
import Button from '../../commonModules/UI/Button';
import { updateCustomer } from '../../../API/authCurd';
import ErrorPopup from '../../commonModules/UI/ErrorPopup';
import UpadateForm from './upadateForm';

const UpdateCust = (props) => {
    const [popMsg, setPopMsg] = useState(false);
    const [isError, setIsError] = useState(false)
    const [errMessage, setErrMessage] = useState();
    const [isUpdating, setIsUpdating] = useState(false)
    const [updatedData, setUpdatedData] = useState(null)

    useEffect(() => {
        if (props?.selectedCustomer) {
            const { name, email, phone, website, type, address1, address2, city, state, management_comment, contract_term, crm, status, } = props?.selectedCustomer
            let data = {
                name: name ?? (name === "" ? "" : name),
                status: status ?? (status === "" ? "" : status),
                email: email ?? (email === "" ? "" : email),
                website: website ?? (website === "" ? "" : website),
                phone: phone ?? (phone === "" ? "" : phone),
                type: type ?? (type === "" ? "" : type),
                address1: address1 ?? (address1 === "" ? "" : address1),
                address2: address2 ?? (address2 === "" ? "" : address2),
                city: city ?? (city === "" ? "" : city),
                state: state ?? (state === "" ? "" : state),
                crm: crm ?? (crm === "" ? "" : crm),
                management_comment: management_comment ?? (management_comment === "" ? "" : management_comment),
                contract_term: contract_term ?? (contract_term === "" ? "" : contract_term)
            }
            setUpdatedData(data)
        }
    }, [props?.selectedCustomer])

    function handleSubmit(event) {
        event.preventDefault();
        setIsUpdating(true)
        updateCustomer(updatedData, props.selectedCustomer.id)
            .then((res) => {
                console.log(res.data.message)
                let SuccessfullyMessage = res.data.message;
                props.getCustomersList()
                setIsUpdating(false)
                setIsError(false)
                setErrMessage(SuccessfullyMessage)
                setPopMsg(true)
            })
            .catch((err) => {
                console.log("err", err)
                let errorMessage = err.response?.data.message || "Something went wrong!";
                setIsUpdating(false)
                setIsError(true)
                setErrMessage(errorMessage)
                setPopMsg(true)
            })
    }

    function errorPopupOnClick() {
        setPopMsg(false)
        if (!isError) {
            props.onClick()
        }
    }

    if (popMsg) {
        return (
            <ErrorPopup title={errMessage} onClick={errorPopupOnClick} />
        )
    }

    return (
        <form onSubmit={handleSubmit}>
            <div className='popups d-flex justify-content-center align-items-center'>
                <div className='addpopups'>
                    <div className='mb-auto pophead d-flex align-items-center justify-content-between'>
                        <div>Update Client</div>
                        <div className='myIcon' type="button" onClick={props.onClick}><MdIcons.MdOutlineClose /></div>
                    </div>
                    <div className='popBody p-3'>
                        <UpadateForm
                            paymentTerms={props.paymentTerms}
                            clientStatus={props.clientStatus}
                            updatedData={updatedData}
                            setUpdatedData={setUpdatedData}
                        />
                    </div>
                    <div className='mt-auto popfoot w-100 p-2'>
                        <div className='d-flex align-items-center justify-content-center'>
                            <Button className="mx-4 cclBtn" onClick={() => { props.onClick() }} >Cancel</Button>
                            <Button type="submit" disable={isUpdating}>Update</Button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
}

export default UpdateCust;
